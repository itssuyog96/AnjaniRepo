package com.ak;

public enum CARDTYPE {
	DEBIT,CREDIT;

}
