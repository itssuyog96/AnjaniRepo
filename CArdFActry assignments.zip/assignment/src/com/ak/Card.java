package com.ak;

import java.io.Serializable;

public abstract class Card implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6152530086863600902L;
	private long CardNo;
	private String HolderName,PAN;
	private int Contact;
	public Card(long cardNo,int contact, String pAN, String holderName) {
		super();
		CardNo = cardNo;
		Contact = contact;
		HolderName = holderName;
		PAN = pAN;
	}

	public long getCardNo() {
		return CardNo;
	}

	public void setCardNo(long cardNo) {
		CardNo = cardNo;
	}

	public int getContact() {
		return Contact;
	}

	public void setContact(int contact) {
		Contact = contact;
	}

	public String getHolderName() {
		return HolderName;
	}

	public void setHolderName(String holderName) {
		HolderName = holderName;
	}

	public String getPAN() {
		return PAN;
	}

	public void setPAN(String pAN) {
		PAN = pAN;
	}
	
	
	

}
