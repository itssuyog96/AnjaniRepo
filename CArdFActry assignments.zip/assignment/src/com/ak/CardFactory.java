package com.ak;

import java.util.Scanner;

public class CardFactory {
	private static long uniqueCardNo = System.currentTimeMillis();
	private static long uniqueAccountNo = System.currentTimeMillis();
	
	public Card issueNewCard(CARDTYPE cardType) {
		int contact;
		String panNo;
		String holderName;
		Scanner scan = new Scanner(System.in);
		long cardNo = generateNewCardNumber();
		
		System.out.println("Enter Your Name :");
		holderName = scan.nextLine();
		System.out.println("Enter Your Contact Number : ");
		contact = scan.nextInt();
		System.out.println("Enter Your PAN Number : ");
		panNo = scan.next();
		
		if(cardType.name() == "DEBIT") {
			long accountLinked = generateNewAccountNumber();
			return new DebitCard(cardNo, contact, panNo, holderName, accountLinked);
		}
		else if(cardType.name() == "CREDIT")
			return new CreditCard(cardNo, contact, panNo, holderName);
		else
			return null;
	}

	private long generateNewAccountNumber() {
		// TODO Auto-generated method stub
		return uniqueAccountNo + 1234l;
	}

	private long generateNewCardNumber() {
		// TODO Auto-generated method stub
		return uniqueCardNo++;
	}
	
	

}
