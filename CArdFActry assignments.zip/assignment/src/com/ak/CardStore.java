package com.ak;

import java.io.*;

public class CardStore {
	private static int i = 0;
	private static Card[] cardList = new Card[100];
	private static final String CARD_PATH = "d:/records/cards.txt";
	
	public void loadCards() {
		
		try(ObjectInputStream in = new ObjectInputStream(new FileInputStream(CARD_PATH))) {
			Object ob = in.readObject();
			
			while(ob != null) {
				cardList[i++] = (Card) ob;
				ob = in.readObject();
			}
		}catch(EOFException e) {
			System.out.println("Currently there is no cards in database.");
		}catch(IOException e) { 
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public void storeCards() {
		try(ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(CARD_PATH))) {
			
			for(Card card: cardList) {
				out.writeObject(card);
				out.flush();
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void add(Card card) {
		cardList[i++] = card;
	}
	
	public Card searchByCardNo(long cardNo) {
		
		for(Card card: cardList) {
			
			if(card != null && card.getCardNo() == cardNo) {
				return card;
			}
		}
		
		return null;
	}
	
	public Card[] findByHolderName(String name) {
		int index = 0;
		Card[] newList = new Card[100];
		
		for(Card card: cardList) {
			
			if(card != null && card.getHolderName().equalsIgnoreCase(name)) {
				newList[index++] = card;
			}
		}
		
		return newList;
	}
	
	}	


