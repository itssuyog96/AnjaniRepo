package com.ak;
import com.ak.Card;

public class CreditCard extends Card {
	private int pointsAccumalated;
	private static final int CREDIT_LIMIT = 40000;
	private static final double INTEREST_RATE = 12.78d;
	private static final int FIRST_TIME_POINTS = 10000;
	
	public CreditCard(long cardNo, int contact, String panNo, String holderName) {
		super(cardNo, contact, panNo, holderName);
		this.pointsAccumalated = FIRST_TIME_POINTS;
	}

	public int getPointsAccumalated() {
		return pointsAccumalated;
	}

	public void setPointsAccumalated(int pointsAccumalated) {
		this.pointsAccumalated = pointsAccumalated;
	}

	

}
