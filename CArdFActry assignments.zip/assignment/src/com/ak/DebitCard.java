package com.ak;
import com.ak.Card;

public class DebitCard extends Card {
	private long accountLinked;
	private static final int MAX_WITHDRAWAL_LIMIT = 10000;
	
	public DebitCard(long cardNo, int contact, String panNo, String holderName, long accountLinked) {
		super(cardNo, contact, panNo, holderName);
		this.accountLinked = accountLinked;
	}

	public long getAccountLinked() {
		return accountLinked;
	}

	public void setAccountLinked(long accountLinked) {
		this.accountLinked = accountLinked;
	}
	
		
	
	

}
