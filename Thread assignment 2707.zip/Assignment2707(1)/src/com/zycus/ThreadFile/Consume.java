package com.zycus.ThreadFile;

import java.util.EmptyStackException;
import java.util.Stack;

public class Consume implements Runnable {
	private Stack<String> consumer ;
	

	

	Consume(Stack<String> consumer) {
		super();
		this.consumer = consumer;
	}



	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true)
		{
			synchronized(consumer)
			{
				if(consumer.isEmpty())
				{
					try {
						consumer.wait();
						System.out.println("Customer went to sleep");
						System.out.println("Producer can Now Initiate");
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else{
					if(consumer.size()==100){
						String del= consumer.pop();
						System.out.println(del);
						consumer.notify();
						
					}
					else{
						consumer.pop();
					}
						
					
				}
			}
		}
		

	}

}
