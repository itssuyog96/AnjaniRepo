package com.zycus.ThreadFile;

import java.util.Stack;

public class ConsumerMain {

	static Stack<String> value =new Stack<String>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Consume c = new Consume(value);
		Producer p = new Producer(value);
		Thread t1 = new Thread(c);

		Thread t2 = new Thread(p);
		t1.start();
		t2.start();
		
		
		

	}

}
