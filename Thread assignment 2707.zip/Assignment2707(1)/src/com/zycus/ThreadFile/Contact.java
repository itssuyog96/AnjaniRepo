package com.zycus.ThreadFile;

public class Contact {
	String fname,lname,email;
	int age;
	long phone;
	
	
	
	Contact(String fname, String lname, String email, int age, long phone) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.email = email;
		this.age = age;
		this.phone = phone;
	}



	@Override
	public String toString() {
		return   fname + "," + lname + "," + email + "," + age + "," + phone;
	}



	String getFname() {
		return fname;
	}



	void setFname(String fname) {
		this.fname = fname;
	}



	String getLname() {
		return lname;
	}



	void setLname(String lname) {
		this.lname = lname;
	}



	String getEmail() {
		return email;
	}



	void setEmail(String email) {
		this.email = email;
	}



	int getAge() {
		return age;
	}



	void setAge(int age) {
		this.age = age;
	}



	long getPhone() {
		return phone;
	}



	void setPhone(long phone) {
		this.phone = phone;
	}
	
	
	

}
