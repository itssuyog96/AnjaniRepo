package com.zycus.ThreadFile;

import java.util.LinkedList;
import java.util.List;

public class ContactApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Contact> List = new LinkedList<>() ;
		Contact c1 = new Contact("AK","Pandey","akp@gmail.com",25,8370475767l);
		Contact c2 = new Contact("Ajay","khan","ajk@gmail.com",25,837044567l);
		Contact c3 = new Contact("farid","singh","fsingh@gmail.com",25,6470475767l);
		Contact c4 = new Contact("rehan","dsouza","rdsouza@gmail.com",25,8364475767l);
		Contact c5 = new Contact("ash","shaikh","ashaikh@gmail.com",25,8370455767l);
		Contact c6 = new Contact("karthik","roy","kroy@gmail.com",25,8370476467l);
		Contact c7 = new Contact("aditya","khurade","akhurade@gmail.com",25,8370475767l);
		Contact c8 = new Contact("saurav","singh","ssngh@gmail.com",25,8370345767l);
		Contact c9 = new Contact("Ansu","sasmal","as@gmail.com",25,83704745343l);
		List.add(c1);
		List.add(c2);
		List.add(c3);
		List.add(c4);
		List.add(c5);
		List.add(c6);
		List.add(c7);
		List.add(c8);
		List.add(c9);
		
		ContactStore store1 = new ContactStore("d:/data/contact1.csv",List);
		ContactStore store2 = new ContactStore("d:/data/contact2.csv",List);
		ContactStore store3 = new ContactStore("d:/data/contact3.csv",List);
		Thread t1 = new Thread(store1);
		Thread t2 = new Thread(store2);
		Thread t3 = new Thread(store3);
		t1.start();
		t2.start();
		t3.start();
		
		
		
	}

}
