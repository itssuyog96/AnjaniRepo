package com.zycus.ThreadFile;

import java.io.*;
import java.util.*;

public class ContactStore implements Runnable {
	 String filename;
	 List<Contact> contactList = new LinkedList<>() ;

	ContactStore(String filename,List<Contact> contact) {
		super();
		this.filename = filename;
		this.contactList = contact;
	
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		
		try {
			FileWriter file = new FileWriter(filename);
			BufferedWriter bw = new BufferedWriter(file);
			System.out.println("Writing Contact list in file by Thread"+Thread.currentThread().getName());
			for(Contact contact:contactList)
			{
	
			bw.write(contact.toString()+"\n");
			}
			bw.close();
			System.out.println("Contacts written Successfully");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
