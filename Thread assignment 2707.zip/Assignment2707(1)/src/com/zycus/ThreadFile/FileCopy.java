package com.zycus.ThreadFile;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class FileCopy implements Runnable {
	
	String source,dest;

	FileCopy(String source, String dest) {
		super();
		this.source = source;
		this.dest = dest;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try{
			FileInputStream fin = new FileInputStream(source);
			FileOutputStream fout = new FileOutputStream(dest);
		FileChannel inchannel= fin.getChannel();
		FileChannel outchannel = fout.getChannel();
		ByteBuffer buffer = ByteBuffer.allocate(1000);
		int readBytes = inchannel.read(buffer);
		    while(readBytes!=-1)
		    {
			buffer.flip();
			outchannel.write(buffer);
			buffer.clear();
			readBytes = inchannel.read(buffer);
			}
		fin.close();
		fout.close();	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
