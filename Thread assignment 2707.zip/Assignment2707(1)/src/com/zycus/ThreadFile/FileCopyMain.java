package com.zycus.ThreadFile;

public class FileCopyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FileCopy fc= new FileCopy("d:/data/source.jpg","d:/data1/copy.jpg");
		Thread t1= new Thread(fc);
		t1.start();
		
		
		try{
			t1.join();
		}catch(InterruptedException e )
		{
			e.printStackTrace();
		}
		
		System.out.println("File Copy Successful");

	}

}
