package com.zycus.ThreadFile;

import java.util.Stack;

public class Producer implements Runnable {
	 private Stack<String> producer ;
	 private static final int STACK_LIMIT=100;
	 private static int  i = 0;
	
	 public Producer(Stack<String> store) {
		super();
		this.producer = store;
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
	
		while(true){
			
			synchronized (producer) {
				
				if(producer.isEmpty())
				{
					producer.push("String "+i++);
					System.out.println("Push Successful on Empty Stack");
	
					producer.notify();
				}
				else{
					producer.push("String "+i++);
					System.out.println("Value inserted Before Stack lIMit check");
					if(producer.size()==STACK_LIMIT)
					{
						try {
							producer.wait();
							System.out.println("Stack Is Full Producer went to sleep"+producer.size());
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
	}

		}
	}
}
