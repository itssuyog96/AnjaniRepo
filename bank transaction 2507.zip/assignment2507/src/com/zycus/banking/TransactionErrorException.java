package com.zycus.banking;

public class TransactionErrorException extends Exception {
	
	TransactionErrorException(String s )
	{
		super(s);
	}
}
