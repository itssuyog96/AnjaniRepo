package com.zycus.banking;

public enum accountType {
	Savings,Current

}
