package com.zycus.banking;

public enum status {
    Active,Closed
}
